package com.loganalyzer.software;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoganalyzerApplicationTests {

	@Test
	void contextLoads() {
	}

}
