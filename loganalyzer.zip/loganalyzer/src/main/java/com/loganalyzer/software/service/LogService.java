package com.loganalyzer.software.service;

import java.util.List;
import com.loganalyzer.software.model.LogRecord;


public interface LogService {

    LogRecord getMostRecentLog(String logType);

    LogRecord getLasterror();



    List<LogRecord> searchLogs(String keywords);

    void saveLogRecords(List<LogRecord> logRecords);
}
