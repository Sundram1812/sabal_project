package com.loganalyzer.software.util;

import com.loganalyzer.software.model.LogRecord;
import com.opencsv.CSVReader;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Component
public class FileParser {

    public static List<LogRecord> parseFile(MultipartFile file){
        List<LogRecord> logRecords = new ArrayList<>();


        try{
            if(file.getOriginalFilename().endsWith(".csv")){
                CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()));
                String[] line;
                while((line = reader.readNext()) != null){
                    logRecords.add(parseLine(line));
                }
            } else if (file.getOriginalFilename().endsWith(".xlsx")) {
                Workbook workbook = WorkbookFactory.create(file.getInputStream());
                Sheet sheet = workbook.getSheetAt(0);
                for(Row row : sheet){
                    String[] line = new String[3];
                    for(int cn = 0;cn < row.getLastCellNum();cn++){
                        line[cn] = row.getCell(cn).toString();
                    }
                    logRecords.add(parseLine(line));
                }

            }
        } catch (Exception e){
            e.printStackTrace();
        }

        return logRecords;

    }

    private static LogRecord parseLine(String[] line){
        LogRecord logRecord = new LogRecord();
        logRecord.setLogType(line[0]);
        logRecord.setTimestamp(LocalDateTime
                .parse(line[1], DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        logRecord.setMessage(line[2]);
        return logRecord;
    }

}
