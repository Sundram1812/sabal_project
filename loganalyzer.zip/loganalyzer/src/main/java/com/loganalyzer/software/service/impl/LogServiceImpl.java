package com.loganalyzer.software.service.impl;

import com.loganalyzer.software.repository.LogRepository;
import com.loganalyzer.software.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import com.loganalyzer.software.model.LogRecord;

@Service
public class LogServiceImpl implements LogService {
    @Autowired
    LogRepository logRepo;

    @Override
    public LogRecord getMostRecentLog(String logType) {
        return logRepo.findFirstByLogTypeOrderByTimestampDesc(logType)
                .stream().findFirst().orElse(null);
    }

    @Override
    public LogRecord getLasterror() {
        return logRepo.findFirstByLogTypeOrderByTimestampDesc("ERROR")
                .stream().findFirst().orElse(null);
    }

    @Override
    public List<LogRecord> searchLogs(String keyword) {
        return logRepo.findByMessageContaining(keyword);
    }

    @Override
    public void saveLogRecords(List<LogRecord> logRecords) {
        logRepo.saveAll(logRecords);
    }
}
