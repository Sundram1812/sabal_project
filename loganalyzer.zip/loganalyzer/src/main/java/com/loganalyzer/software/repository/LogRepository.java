package com.loganalyzer.software.repository;

import com.loganalyzer.software.model.LogRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;



public interface LogRepository extends JpaRepository<LogRecord,Long> {

    List<LogRecord> findFirstByLogTypeOrderByTimestampDesc(String logType);
    List<LogRecord> findByMessageContaining(String message);


}
