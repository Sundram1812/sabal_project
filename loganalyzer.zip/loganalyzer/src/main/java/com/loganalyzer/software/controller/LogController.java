package com.loganalyzer.software.controller;

import com.loganalyzer.software.model.LogRecord;
import com.loganalyzer.software.util.FileParser;
import com.loganalyzer.software.service.impl.LogServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/logs")
public class LogController {
    @Autowired
    LogServiceImpl logService;

    @PostMapping("/upload")
    public String uploadLogFile(@RequestParam("file")MultipartFile file){
        List<LogRecord> logRecords = FileParser.parseFile(file);
        logService.saveLogRecords(logRecords);
      return "File uploaded successfully";
    }
    @GetMapping("/recent")
    public LogRecord getMostrecentLog(@RequestParam("type") String logType){
        return logService.getMostRecentLog(logType);
    }

    @GetMapping("/last-error")
    public LogRecord getLastError(){
        return logService.getLasterror();
    }

    @GetMapping("/search")
    public List<LogRecord> searchLogs(@RequestParam("keyword") String keyword){
        return logService.searchLogs(keyword);
    }

}
